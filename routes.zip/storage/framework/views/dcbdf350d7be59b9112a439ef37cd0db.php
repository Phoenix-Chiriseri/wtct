<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/css/bootstrap.min.css')); ?>" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> 
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="jumbotron">
                <h1 class="display-4">Add New Position</h1>
                <hr class="my-4">
            </div>
        </div>
    </div>
</div>  
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header texty-center"></div>
                <div class="card-body">
                <?php if(Session::has('success')): ?>
                <script type="text/javascript">
                function massge() {
                Swal.fire(
                'Success',
                'Support Worker Added Successfully'
                    );
                    }
                    window.onload = massge;
                    </script>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('postNewPosition')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="date"><?php echo e(__('Position')); ?></label>
                            <input id="" type="text" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="position" required>
                            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <?php echo e(__('Add Or Remove')); ?>

                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\Users\TechUrve\Desktop\WtctJobBoard\resources\views/newPosition.blade.php ENDPATH**/ ?>