<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/css/bootstrap.min.css')); ?>" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div class="container" style="margin-top: 10px;">
<section class="section">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Delete Midwives</h5>
            </div>
          </div>
        </div>
      </div>
    </section>
</div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header texty-center"></div>
                <div class="card-body">
                <?php if(Session::has('success')): ?>
                <script type="text/javascript">
                function massge() {
                Swal.fire(
                'Success',
                'Midwives Deleted'
                    );
                    }
                    window.onload = massge;
                    </script>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('deleteMentalHealthAction')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="date"><?php echo e(__('From Date')); ?></label>
                            <input id="date" type="date" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="from_date" required>
                            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <hr>
                        <div class="form-group">
                            <label for="date"><?php echo e(__('To Date')); ?></label>
                            <input id="date" type="date" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="to_date" required>
                            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <hr>
                        <button type="submit" class="btn btn-secondary">
                            <i class="fa-regular fa-user"></i><?php echo e(__('Delete Records ')); ?></button>
                    </form>
                    <br>
                    </button>
                    <a href="/home" class="btn btn-danger">Home</a>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\Users\TechUrve\Desktop\WtctJobBoard\resources\views/deleteMidwives.blade.php ENDPATH**/ ?>